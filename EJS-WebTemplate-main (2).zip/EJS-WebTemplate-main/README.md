# EJS-WebTemplate
A simple ExpressJS Web Template designed to be used for practically any project.
